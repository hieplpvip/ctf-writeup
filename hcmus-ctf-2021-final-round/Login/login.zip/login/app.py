import jwt
import os
import sqlite3
from flask import Flask, g, request, render_template, jsonify, make_response, redirect, flash

app = Flask(__name__)
app.secret_key = "[REDACTED]"
DB_PATH = "users.db"


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("DELETE FROM users")
    admin_password = os.urandom(32).hex()
    cur.execute(
        "INSERT INTO users(username, password) VALUES ('%s', '%s')" %
        ("admin", admin_password)
    )
    con.commit()
    cur.close()


init_db()


app.config.update(
    PUBLIC_KEY=open("public.pem", "rb").read(),
    PRIVATE_KEY=open("private.pem", "rb").read(),
    FLAG=open("flag.txt", "r").read()
)


@app.route("/")
def index():
    token = request.cookies.get("token")
    try:
        user = jwt.decode(token, app.config["PUBLIC_KEY"])
        if user["username"] == "admin":
            name = "Admin"
            flag = "Flag: " + app.config["FLAG"]
        else:
            name = "Guest"
            flag = "Login as admin to get flag"
        return render_template(
            "index.html",
            user=name,
            flag=flag
        )
    except Exception as e:
        print(e)
        return redirect("/login")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    username = request.form.get("username")
    password = request.form.get("password")
    try:
        cur = get_db().cursor()
        cur.execute(
            "INSERT INTO users(username, password) VALUES ('%s', '%s')" %
            (username, password)
        )
        get_db().commit()
        token = jwt.encode(
            {"username": cur.lastrowid},
            key=app.config["PRIVATE_KEY"],
            algorithm="RS256"
        )
        res = make_response(redirect("/"))
        res.set_cookie("token", token)
        return res
    except Exception as e:
        print(e)
        flash("Something went wrong. Please try again.")
        return redirect("/register")
    finally:
        cur.close()


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    username = request.form.get("username")
    password = request.form.get("password")

    try:
        cur = get_db().cursor()
        cur.execute("SELECT * FROM users WHERE username = '%s' and password = '%s'" %
                    (username, password))
        user_list = cur.fetchall()
        if len(user_list) != 1:
            raise Exception()

        token = jwt.encode(
            {"username": user_list[0][0]},
            key=app.config["PRIVATE_KEY"],
            algorithm="RS256"
        )

        res = make_response(redirect("/"))
        res.set_cookie("token", token)

        return res
    except Exception as e:
        print(e)
        flash("Something went wrong. Please try again.")
        return redirect("/login")
    finally:
        cur.close()


@app.route("/logout")
def logout():
    res = make_response(redirect("/login"))
    res.delete_cookie("token")

    return res


if __name__ == "__main__":
    app.run("0.0.0.0", 5000, debug=True)
