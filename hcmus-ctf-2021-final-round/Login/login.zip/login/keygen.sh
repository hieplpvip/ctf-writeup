#!/bin/bash
ssh-keygen -t rsa -P "" -b 2048 -m PEM -f jwtRS256.key
ssh-keygen -f jwtRS256.key.pub -e -m pem > public.pem
rm jwtRS256.key.pub
mv jwtRS256.key private.pem