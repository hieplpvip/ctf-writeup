const express = require("express");
const session = require('express-session');
const config = require("./config");
const MongoClient = require('mongodb').MongoClient;
var db;
const app = express();
const port = process.env.APP_PORT || 8080;
const host = "0.0.0.0";

app.use(session(config.session));
app.set("view engine", "pug");
app.use(express.static("public"));
app.use(express.urlencoded({extended: true}));

app.use((req, res, next) => {
    const allowedType = ["string", "number"];
    for (key in req.query) {
        if (!allowedType.includes(typeof (req.query[key])))
            return res.send("Nice try");
    }
    for (key in req.body) {
        if (!allowedType.includes(typeof (req.body[key])))
            return res.send("Nice try");
    }
    next();
})

app.route("/")
    .all((req, res, next) => {
        if (!req.session.authenticated)
            return res.redirect("/register");
        next();
    })
    .get((req, res) => {
        req.session.user.pokemon = Math.floor(Math.random()*3);
        req.session.user.health = Math.floor(Math.random()*4) + 1;
        req.session.user.power = Math.floor(Math.random()*4) + 1;
        res.render("index", req.session.user);
    });

app.route("/register")
    .all((req, res, next) => {
        if (req.session.authenticated)
            return res.redirect("/");
        next();
    })
    .get((req, res) => {
        return res.render("register");
    })
    .post((req, res) => {
        user = {...req.body, health: Math.floor(Math.random()*4) + 1, power: Math.floor(Math.random()*4) + 1};
        db.collection("users").insertOne(user);
        req.session.authenticated = true;
        req.session.user = {};
        req.session.user.username = req.body.username;
        return res.redirect("/");
    })

app.route("/login")
    .all((req, res, next) => {
        if (req.session.authenticated)
            return res.redirect("/");
        next();
    })
    .get((req, res) => {
        return res.render("login");
    })
    .post((req, res) => {
        db.collection("users").findOne(
            {username: req.body.username, password: req.body.password}, 
            (err, result) => {
                if (err)
                    return res.render("login", {error: "Something error"});
                if (!result)
                    return res.render("login", {error: "Wrong username or password"});
                req.session.authenticated = true;
                req.session.user = {};
                req.session.user.username = result.username;
                return res.render("index", result);
        });
    })

MongoClient.connect("mongodb://mongo:27017/pokegen", (err, client) => {
    if (err) { 
        console.log(err);
        return;
    }
    db = client.db("pokegen");
    app.listen(port, host);
    console.log(`Running on http://${host}:${port}`);
    });