var config = {};
config.session = {
    secret: process.env.SESSION_SECRET || "random secret",  
    resave: true,
    saveUninitialized: true,
}


module.exports = config;