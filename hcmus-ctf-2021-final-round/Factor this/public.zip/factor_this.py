from Crypto.Util import number
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import random
import math
from typing import Tuple, Dict

def two_square_small(p: int) -> Tuple[int, int]:
	for x in range(math.isqrt(p)):
		y2 = p - x**2
		y = math.isqrt(y2)
		if y**2 == y2:
			return (x, y)
	raise Exception('do not have any two square decomposition')

# a^2+b^2 = x
# c^2+d^2 = y
# => (a*c + b*d)^2 + (a*d - b*c)^2 == x * y
def two_square_multiply(a: Tuple[int, int], b: Tuple[int, int]) -> Tuple[int, int]:
	u = a[0]*b[0] + a[1]*b[1]
	v = abs(a[0]*b[1] - a[1]*b[0])
	return (u, v)

def prepare_prime_power(bound):
    prime_power = {}
    for i in range(3, bound + 1):
        if number.isPrime(i):
            if i % 4 == 3:
                i = i ** 2
            exp = int(math.log(bound, i))
            if exp > 0:
                prime_power[i] = exp
    return prime_power

def gen_weird_smooth_number(bits: int, prime_power: Dict[int, int]) -> Tuple[int, Tuple[int,int]]:
    prime_power = prime_power.copy()

    smooth = 8
    two_square = (2, 2) #2^2 + 2^2 = 8
    while smooth.bit_length() < bits:
        p = random.choice(list(prime_power.keys()))
        prime_power[p] -= 1
        if prime_power[p] <= 0:
            del prime_power[p]
        smooth *= p
        two_square = two_square_multiply(two_square, two_square_small(p))

    return smooth, two_square

def gen_weird_prime(bits: int, smooth_bound: int) -> int:
    prime_power = prepare_prime_power(smooth_bound)
    while True:
        s, (a, b)= gen_weird_smooth_number(bits, prime_power)
        assert a**2 + b**2 == s
        if number.isPrime(s - 2 * a + 1):
            break
        if number.isPrime(s - 2 * b + 1):
            a, b = b, a
            break
    return s - 2*a + 1


p = gen_weird_prime(512, 2**12)
q = number.getPrime(512)
n = p * q
phi = (p-1) * (q-1)

while True:
    e = random.randint(2,phi-1)
    if math.gcd(e,phi) == 1:
        break

d = pow(e, -1, phi)

key = RSA.construct((n, e, d, p, q))
cipher = PKCS1_OAEP.new(key)

with open('flag.txt', 'rb') as f:
    c =  cipher.encrypt(f.read().strip()).hex()

print(f'n = {n}')
print(f'e = {e}')
print(f'c = {c}')